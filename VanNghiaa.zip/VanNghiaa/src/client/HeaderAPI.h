#ifndef HeaderAPI_h
#define HeaderAPI_h

#import <Foundation/Foundation.h>

static NSString *const kBaseAPIURL = @"http://YOUR_DOMAIN/api/connect.php";

static NSString *const kPackageToken = @"YOU_TOKEN_PACKAGE"; 

#endif
