// Helper functions for future expansion
console.log("Helper loaded");