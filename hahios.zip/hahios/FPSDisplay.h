#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface FPSDisplay : NSObject
+ (instancetype)shareFPSDisplay;
@end
