//RexVN
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface IGGViewa : UIView

+ (instancetype)View;
- (void)show;
+ (void)closeMenu;
+ (void)expand;

@end

NS_ASSUME_NONNULL_END
