//Require standard library
#import <Metal/Metal.h>
#import <MetalKit/MetalKit.h>
#import <Foundation/Foundation.h>
#include <iostream>
#include <UIKit/UIKit.h>
#include <vector>
#import "pthread.h"
#include <array>
#import <os/log.h>
#include <cmath>
#include <deque>
#include <fstream>
#include <algorithm>
#include <string>
#include <sstream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <cstdint>
#include <cinttypes>
#include <cerrno>
#include <cctype>
//Imgui library
#import "Esp/CaptainHook.h"
#import "Esp/ImGuiDrawView.h"
#import "IMGUI/imgui.h"
#import "IMGUI/imgui_internal.h"
#import "IMGUI/imgui_impl_metal.h"
#import "IMGUI/zzz.h"
#include "oxorany/oxorany_include.h"
#import "Helper/Mem.h"
#include "font.h"
#import "Helper/Vector3.h"
#import "Helper/Vector2.h"
#import "Helper/Quaternion.h"
#import "Helper/Monostring.h"
#include "Helper/font.h"
#include "Helper/data.h"
ImFont* verdana_smol;
ImFont* pixel_big = {};
ImFont* pixel_smol = {};
#include "Helper/Obfuscate.h"
#import "Helper/Hooks.h"
#include <OpenGLES/ES2/gl.h>
#include <OpenGLES/ES2/glext.h>
#include <unistd.h>
#include <string.h>

#define kWidth  [UIScreen mainScreen].bounds.size.width
#define kHeight [UIScreen mainScreen].bounds.size.height
#define kScale [UIScreen mainScreen].scale

@interface ImGuiDrawView () <MTKViewDelegate>
@property (nonatomic, strong) id <MTLDevice> device;
@property (nonatomic, strong) id <MTLCommandQueue> commandQueue;
@end

@implementation ImGuiDrawView
ImFont *_espFont;
ImFont* verdanab;
ImFont* icons;
ImFont* interb;
ImFont* Urbanist;
static bool MenDeal = true;

bool rsttk = false;
bool Guest(void* _this){
    if (rsttk){
      return true;
    } else { return true; 
}
}


- (instancetype)initWithNibName:(nullable NSString *)nibNameOrNil bundle:(nullable NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];

    _device = MTLCreateSystemDefaultDevice();
    _commandQueue = [_device newCommandQueue];

    if (!self.device) abort();

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;

   ImGui::StyleColorsClassic();


ImGuiStyle& style = ImGui::GetStyle();

// ====== Layout ======
style.WindowPadding = ImVec2(8.0f, 8.0f);
style.FramePadding  = ImVec2(9.0f, 7.0f);
style.ScrollbarRounding = 9.0f;

style.WindowRounding = 6.0f;
style.FrameRounding  = 4.0f;
style.ChildRounding  = 5.0f;

// ====== Colors ======
ImVec4* colors = style.Colors;

// خلفيات سوداء شفافة
colors[ImGuiCol_WindowBg]  = ImVec4(0.03f, 0.03f, 0.03f, 0.85f);
colors[ImGuiCol_ChildBg]   = ImVec4(0.03f, 0.03f, 0.03f, 0.70f);
colors[ImGuiCol_PopupBg]   = ImVec4(0.04f, 0.04f, 0.04f, 0.90f);

// Frames
colors[ImGuiCol_FrameBg]        = ImVec4(0.10f, 0.10f, 0.10f, 0.60f);
colors[ImGuiCol_FrameBgHovered] = ImVec4(0.60f, 0.10f, 0.10f, 0.60f);
colors[ImGuiCol_FrameBgActive]  = ImVec4(0.80f, 0.15f, 0.15f, 0.90f);

// Buttons
colors[ImGuiCol_Button]        = ImVec4(0.55f, 0.10f, 0.10f, 0.55f);
colors[ImGuiCol_ButtonHovered] = ImVec4(0.75f, 0.15f, 0.15f, 0.85f);
colors[ImGuiCol_ButtonActive]  = ImVec4(0.90f, 0.20f, 0.20f, 1.00f);

// Header / Tabs
colors[ImGuiCol_Header]        = ImVec4(0.60f, 0.12f, 0.12f, 0.55f);
colors[ImGuiCol_HeaderHovered] = ImVec4(0.80f, 0.15f, 0.15f, 0.85f);
colors[ImGuiCol_HeaderActive]  = ImVec4(1.00f, 0.20f, 0.20f, 1.00f);

colors[ImGuiCol_Tab]                = ImVec4(0.12f, 0.12f, 0.12f, 0.80f);
colors[ImGuiCol_TabHovered]         = ImVec4(0.80f, 0.15f, 0.15f, 0.80f);
colors[ImGuiCol_TabActive]          = ImVec4(0.90f, 0.20f, 0.20f, 1.00f);
colors[ImGuiCol_TabUnfocused]       = ImVec4(0.10f, 0.10f, 0.10f, 0.80f);
colors[ImGuiCol_TabUnfocusedActive] = ImVec4(0.70f, 0.15f, 0.15f, 0.90f);

// Check / Slider / Resize
colors[ImGuiCol_CheckMark]          = ImVec4(1.00f, 0.20f, 0.20f, 1.00f);
colors[ImGuiCol_SliderGrab]         = ImVec4(0.90f, 0.20f, 0.20f, 1.00f);
colors[ImGuiCol_SliderGrabActive]   = ImVec4(1.00f, 0.30f, 0.30f, 1.00f);
colors[ImGuiCol_ResizeGrip]         = ImVec4(0.90f, 0.20f, 0.20f, 0.80f);
colors[ImGuiCol_ResizeGripHovered]  = ImVec4(1.00f, 0.30f, 0.30f, 1.00f);
colors[ImGuiCol_ResizeGripActive]   = ImVec4(1.00f, 0.40f, 0.40f, 1.00f);

// Scrollbar
colors[ImGuiCol_ScrollbarBg]        = ImVec4(0, 0, 0, 0);
colors[ImGuiCol_ScrollbarGrab]      = ImVec4(0.80f, 0.15f, 0.15f, 0.80f);
colors[ImGuiCol_ScrollbarGrabHovered]=ImVec4(0.95f, 0.25f, 0.25f, 1.00f);

// Borders
colors[ImGuiCol_Border] = ImVec4(0.30f, 0.05f, 0.05f, 0.80f);

// ====== Fonts ======
ImFont* font = io.Fonts->AddFontFromMemoryTTF(
    sansbold, sizeof(sansbold), 15.0f, nullptr,
    io.Fonts->GetGlyphRangesCyrillic());

verdana_smol = io.Fonts->AddFontFromMemoryTTF(
    verdana, sizeof(verdana), 40, nullptr,
    io.Fonts->GetGlyphRangesCyrillic());

pixel_big = io.Fonts->AddFontFromMemoryTTF(
    (void*)smallestpixel, sizeof(smallestpixel), 128, nullptr,
    io.Fonts->GetGlyphRangesCyrillic());

pixel_smol = io.Fonts->AddFontFromMemoryTTF(
    (void*)smallestpixel, sizeof(smallestpixel), 20, nullptr,
    io.Fonts->GetGlyphRangesCyrillic());

// ====== Metal ======
ImGui_ImplMetal_Init(_device);

    return self;
}

+ (void)showChange:(BOOL)open
{
    MenDeal = open;
}

- (MTKView *)mtkView
{
    return (MTKView *)self.view;
}

- (void)loadView
{

 

    CGFloat w = [UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.width;
    CGFloat h = [UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.height;
    self.view = [[MTKView alloc] initWithFrame:CGRectMake(0, 0, w, h)];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.mtkView.device = self.device;
    self.mtkView.delegate = self;
    self.mtkView.clearColor = MTLClearColorMake(0, 0, 0, 0);
    self.mtkView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
    self.mtkView.clipsToBounds = YES;

}

void* address[] = {
        (void*)getRealOffset(0x10126E688),
    };
    void* function[] = {
        (void*)Guest,
    };

#pragma mark - Interaction

- (void)updateIOWithTouchEvent:(UIEvent *)event
{
    UITouch *anyTouch = event.allTouches.anyObject;
    CGPoint touchLocation = [anyTouch locationInView:self.view];
    ImGuiIO &io = ImGui::GetIO();
    io.MousePos = ImVec2(touchLocation.x, touchLocation.y);

    BOOL hasActiveTouch = NO;
    for (UITouch *touch in event.allTouches)
    {
        if (touch.phase != UITouchPhaseEnded && touch.phase != UITouchPhaseCancelled)
        {
            hasActiveTouch = YES;
            break;
        }
    }
    io.MouseDown[0] = hasActiveTouch;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

#pragma mark - MTKViewDelegate

- (void)drawInMTKView:(MTKView*)view
{
    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize.x = view.bounds.size.width;
    io.DisplaySize.y = view.bounds.size.height;

    CGFloat framebufferScale = view.window.screen.nativeScale ?: UIScreen.mainScreen.nativeScale;
    io.DisplayFramebufferScale = ImVec2(framebufferScale, framebufferScale);
    io.DeltaTime = 1 / float(view.preferredFramesPerSecond ?: 60);
    
    id<MTLCommandBuffer> commandBuffer = [self.commandQueue commandBuffer];
        
        if (MenDeal == true) 
        {
            [self.view setUserInteractionEnabled:YES];
            
        } 
        else if (MenDeal == false) 
        {
           
            [self.view setUserInteractionEnabled:NO];
           

        }

        MTLRenderPassDescriptor* renderPassDescriptor = view.currentRenderPassDescriptor;
        if (renderPassDescriptor != nil)
        {
            id <MTLRenderCommandEncoder> renderEncoder = [commandBuffer renderCommandEncoderWithDescriptor:renderPassDescriptor];
            [renderEncoder pushDebugGroup:@"ImGui Jane"];

            ImGui_ImplMetal_NewFrame(renderPassDescriptor);
            ImGui::NewFrame();
    CGFloat x = (([UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.width) - 380) / 2;
    CGFloat y = (([UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.height) - 260) / 2;
     ImGui::SetNextWindowPos(ImVec2(x, y), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(365, 270), ImGuiCond_FirstUseEver);
            if (MenDeal == true)
            {                
                ImGui::Begin(oxorany("DlvXx VS ALL"), &MenDeal);
                if (ImGui::BeginTabBar(oxorany("Tab"),ImGuiTabBarFlags_FittingPolicyScroll)) {
                    if (ImGui::BeginTabItem(("ESP"))) {
                    ImGui::Checkbox(oxorany("Enable Cheats"), &Vars.Enable);
                        if (ImGui::BeginTable("split", 4))
                    {
                    ImGui::TableNextColumn();
                    ImGui::Checkbox(oxorany("Line"), &Vars.lines);
                    ImGui::TableNextColumn();
                    ImGui::Checkbox(oxorany("Box"), &Vars.Box);
                    ImGui::TableNextColumn();
                    ImGui::Checkbox(oxorany("Health"), &Vars.Health);
                    ImGui::TableNextColumn();
                    ImGui::Checkbox(oxorany("Name"), &Vars.Name);
                    ImGui::TableNextColumn();
                    ImGui::Checkbox(oxorany("Skeleton"), &Vars.skeleton);
                    ImGui::TableNextColumn();
                    ImGui::Checkbox(oxorany("Distance"), &Vars.Distance);
                    ImGui::TableNextColumn();
                    ImGui::Checkbox(oxorany("3D Circle"), &Vars.circlepos);
                    ImGui::TableNextColumn();
                    ImGui::Checkbox(oxorany("Outline"), &Vars.Outline);
                        }
                        ImGui::EndTable();
                        ImGui::Checkbox(oxorany("Out of Screen"), &Vars.OOF);ImGui::SameLine();
                        ImGui::Checkbox(oxorany("Enemy Count"), &Vars.enemycount);
                        ImGui::EndTabItem();
                    }
                    if (ImGui::BeginTabItem(("AimBot"))) {
                            ImGui::Spacing();
                            ImGui::Checkbox(oxorany("Enable Aimbot"), &Vars.Aimbot);
                            ImGui::Combo(oxorany("Aim When"), &Vars.AimWhen, Vars.dir, 4);
                            ImGui::SliderFloat(oxorany("Aim FOV"), &Vars.AimFov, 0.0f, 500.0f);
                            ImGui::Checkbox(oxorany("FOV Glow"), &Vars.fovaimglow);
                            if (Vars.fovaimglow) {
                                ImGui::ColorEdit4(oxorany("FOV Color"), Vars.fovLineColor);
                            }

     ImGui::Checkbox("RESET GUEST", &rsttk);

ImGui::EndTabItem();
                    }
                    if 
(ImGui::BeginTabItem(("Info Developer"))) {
                        ImGui::TextDisabled("L3B B DYALI W SBNI AW9 ");
                        
                        ImGui::EndTabItem();
                    }
                    ImGui::EndTabBar();
                }
        ImGui::End();
    }
            ImDrawList* draw_list = ImGui::GetBackgroundDrawList();
            get_players();
            draw_watermark();
            aimbot();
            game_sdk->init();
            if (Vars.AimFov > 0) {
                Vars.isAimFov = true;
            } else {
                Vars.isAimFov = false;
            }
            ImGui::Render();
            ImDrawData* draw_data = ImGui::GetDrawData();
            ImGui_ImplMetal_RenderDrawData(draw_data, commandBuffer, renderEncoder);
          
            [renderEncoder popDebugGroup];
            [renderEncoder endEncoding];

            [commandBuffer presentDrawable:view.currentDrawable];
        }

        [commandBuffer commit];
}

- (void)mtkView:(MTKView*)view drawableSizeWillChange:(CGSize)size
{
    
}

@end

