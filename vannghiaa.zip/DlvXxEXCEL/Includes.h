#include "LoadView/Includes.h"
#include "oxorany/oxorany_include.h"
#import "LoadView/DTTJailbreakDetection.h"
#import "Helper/Mem.h"
#include "font.h"
#import "Hosts/hookURL.h"
#import "Hosts/EtcHostsURLProtocol.h"
#import "Hosts/NSObject+URL.h"
#include "hook/hook.h"
#import "Helper/Vector3.h"
#import "Helper/Vector2.h"
#import "Helper/Quaternion.h"
#import "Helper/MonoString.h"
#include "Helper/font.h"
#include "Helper/data.h"
ImFont* verdana_smol;
ImFont* pixel_big = {};
ImFont* pixel_smol = {};
#import "Helper/Hooks.h"
#include <OpenGLES/ES2/gl.h>
#include <OpenGLES/ES2/glext.h>
#include <unistd.h>
#include <string.h>